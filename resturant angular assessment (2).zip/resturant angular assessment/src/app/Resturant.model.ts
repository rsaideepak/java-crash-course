export interface Resturant {
  resturantName: string;
   resturantId: number;
  location: string;
   rating: number;
}
