package com.java.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.java.dbutil.Dbconn;
import com.java.pojo.Customer;
public class Customerdao {
	
	public String retriveid(String firstname,String lastname){
		int cust_id=0;
		String name1=firstname.substring(0,2);
		String name2=lastname.substring(0,2);
		try{
		Connection con=Dbconn.getConnection();
		
        
        String sql1="SELECT custid.NEXTVAL FROM DUAL";
        
        PreparedStatement stat1=con.prepareStatement(sql1);
        ResultSet rs = stat1.executeQuery();
        
        if ( rs.next() ) 
        {
          cust_id = rs.getInt(1);
          System.out.println(cust_id);
        }          
        else 
        {
          return "cannot access sequence";
        }
		}
		catch(Exception e){
			e.printStackTrace();
		}

		
		
		return name1+name2+"00"+cust_id;
		
	}
	
	
	
	public String saveCustomer(Customer customer)
	{
	try
	{
	Connection con=Dbconn.getConnection();

	String sql="insert into customer values(?,?,?,?)";
     
	PreparedStatement stat=con.prepareStatement(sql);

	stat.setString(1, customer.getFirstname());
	stat.setString(2, customer.getLastname());
	stat.setString(3, customer.getAddress());
	stat.setString(4, retriveid(customer.getFirstname(),customer.getLastname()));
	
	


	int res= stat.executeUpdate();
	if(res>0)
	return "customer saved";


	}
	catch (Exception e) {
	e.printStackTrace();
	}

	return "Cannot save Customer";

	}
}
