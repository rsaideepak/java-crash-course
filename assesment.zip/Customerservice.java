package com.java.service;
import com.java.dao.Customerdao;
import com.java.pojo.Customer;



public class Customerservice {

	public static void main(String[] args) {
		Customerdao customerdao=new Customerdao();
		
		
		Customer customer1=new Customer("virat","kohli","bang","");
		String result=customerdao.saveCustomer(customer1);
		System.out.println(result);

	}

}
