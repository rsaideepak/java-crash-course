package com.java.pojo;

public class Customer {
	String firstname;
	String lastname;
	String address;
	String customerid;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCustomerid() {
		return customerid;
	}
	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}
	
	public Customer(String firstname, String lastname, String address,
			String customerid) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.address = address;
		this.customerid = customerid;
	}
	public String toString() {

	return getFirstname()+" "+getLastname()+" "+getAddress()+" "+getCustomerid();

	}

}
