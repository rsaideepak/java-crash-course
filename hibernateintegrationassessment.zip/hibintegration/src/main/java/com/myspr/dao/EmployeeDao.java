package com.myspr.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.myspr.model.Employee;

@Component
public class EmployeeDao {

	
	@Autowired
	SessionFactory sessionFactory;
	
	@Transactional
	public void saveEmployee(Employee employee) {
		
		Session session=sessionFactory.getCurrentSession();
		session.save(employee);
	}
	ArrayList<Employee> emp=new ArrayList<Employee>();
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Employee> getAllEmployees() {
		Session session=sessionFactory.getCurrentSession();
		
        emp=(ArrayList<Employee>) session.createQuery("from Employee").list();
        return emp;
    }
	@Transactional
	public void deleteEmployee(Integer empid) {
        Employee employee = (Employee) sessionFactory.getCurrentSession().load(
                Employee.class, empid);
        if (null != employee) {
            this.sessionFactory.getCurrentSession().delete(employee);
        }
    }
	@Transactional
	public Employee employeebyid(Integer empid) {
		Session session=sessionFactory.getCurrentSession();
		Employee employee=(Employee) session.get(Employee.class, empid);
				return employee;
	}
	@Transactional
	public String update(int empid,String empname,int empage) {
		Session session=sessionFactory.getCurrentSession();
		Employee e=new Employee();
		e.setEmpage(empage);
		e.setEmpid(empid);
		e.setEmpname(empname);
		session.update(e);
		return "updated";
	}
	@Transactional
	public void delete(int empid) {
		Session session=sessionFactory.getCurrentSession();
		Employee e=(Employee) session.get(Employee.class, empid);
		session.delete(e);
		

	}

}
