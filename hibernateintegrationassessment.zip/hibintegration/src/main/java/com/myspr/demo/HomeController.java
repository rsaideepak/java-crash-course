package com.myspr.demo;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.myspr.dao.EmployeeDao;
import com.myspr.model.Employee;


@Controller
public class HomeController {
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		return "home";
	}
	
	
	
	@Autowired
	EmployeeDao employeeDao;
	
	
	
	@RequestMapping(value = "/saveEmployee")
	public String saveEmployee(@ModelAttribute Employee employee) {
		
		
		employeeDao.saveEmployee(employee);
		return "home";
	}
	
	
	
	
	@RequestMapping(value = "/displayEmployee")
	public String listEmployees(ModelMap map)
    {
        map.addAttribute("employee", new Employee());
        map.addAttribute("employeeList", employeeDao.getAllEmployees());
        return "home1";
    }
	
	
	
	
	@RequestMapping("/deleteEmployee/{empid}")
    public String deleteEmplyee(@PathVariable("empid") Integer empid)
    {
        employeeDao.deleteEmployee(empid);
        return "home";
    }
	
	
	
	@RequestMapping(value="/displaybyId")
	public String dbid()
	{
		return "home2";
	}
	
	
	
	@RequestMapping(value="/displayEmp")
	public String dbid(Model m, @RequestParam("empid") int id)
	{
		Employee e = employeeDao.employeebyid(id);
		m.addAttribute("emp",e);
		return "viewEmp";
	}  
	@RequestMapping(value="/edit")
	public String dbi()
	{
		return "update";
	}
	@RequestMapping(value = "/updated")
	public String edit(Model m,@RequestParam("empid") int empid,@RequestParam("empname") String empname,@RequestParam("empage") int empage) {
		String b=employeeDao.update(empid,empname,empage);
		m.addAttribute("Employee",b);
		return "home";
	}
	@RequestMapping(value="/delete1")
		
	public String dbil()
	{
		return "delete";
	}
	
	@RequestMapping(value="/delete")
	public String del(@RequestParam int empid) {
		 employeeDao.delete(empid);
		return "home";
	}
	

}
